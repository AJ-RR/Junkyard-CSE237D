#! /bin./bash

apt-get update
apt-get install -y openssh-client curl jq zip